

// let imagesCertificat = document.getElementsByClassName('certificat-wrap');

// for (var i = 0; i < imagesCertificat.length; i++){  
//     imagesCertificat[i].addEventListener('click', show_img, false); 
// }

// function show_img(event){

//     let img_info      = event.target;
//     console.log(img_info.img);
//     let imgContainer  = document.getElementById('content-img-certificat') 
//     let imgContent    = imgContainer.querySelector("#big-picture");
//     // imgContent.src    = img_info.src;
    
    
//     // imgContainer.classList.toggle("visible");
    
//     // imgContent.addEventListener("click", closeImg, false);
//   }
  
//   // fermé l'image agrandir
//   function closeImg(){
//     let imgContainer  = document.getElementById('content-img-certificat');
//     imgContainer.classList.toggle("visible");
//   }
  